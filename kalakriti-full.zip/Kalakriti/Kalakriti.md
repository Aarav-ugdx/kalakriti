---
type: project
project: Kalakriti
tags: [project/kalakriti, hackathon, domain/health-wellbeing]
created: 2026-09-26
updated: 2026-09-26T18:10
status: round-1-content-complete
gate: Round 1 submission — closes 27 Sep 2026, 12:00 IST
---
# Kalakriti — "design your heart out"

Design hackathon run by Veer Ladhani & Archit Sehgal. Three themes: Sustainability, Health & Well-Being, FinTech. One theme + one scenario chosen, locked for both rounds.

**Chosen: Health & Well-Being → Scenario 2 — Cult.fit.**
*Imaginary pivot: Cult.fit expands beyond fitness into on-demand mental health & therapy booking, integrated into the existing app and membership.*

## Timeline (real, not theoretical)

- **Round 1:** 26–27 Sep 2026. Online. Submit via Forms. **Closes 12:00 IST, 27 Sep** — roughly a 21-hour window from kickoff.
- **Round 2 (if shortlisted):** 29 Sep 2026, offline at MPSTME Mumbai (online option for non-Mumbai teams). Live presentation defending the Round 1 choices.

Contact: Veer Ladhani (8108652511), Archit Sehgal (8305108072).

## Round 1 deliverable (locked scope) — content complete

Screen flow covering, in order: **therapist discovery → booking confirmation → mood-tracking dashboard → content/resource screen.**
Format: a clickable prototype or an annotated screen flow — going with the **annotated screen flow**: `design/screens.html` (annotated, all 6 screens side by side) plus the README screenshots. An experimental clickable prototype (with 3 onboarding screens ahead of the required 4) was also built along the way, then deliberately **removed** from the repo on 26 Sep so it couldn't be mistaken for a submitted/functional screen — see `Repo/brief/WORKFLOW.md`. Submission mode Love confirmed: a public Figma/Canva/design-tool link, **or** a public GitHub repo with screenshots in the README. Private links are skipped and not the organisers' problem — so whatever ships must be reachable with no login.

**The graded four-screen order and Aurora direction remain locked.** The local submission files now include targeted copy, accessibility, interaction, and screenshot updates. The broader service ideas stay in `Repo/product-concept/`.

## Brand fidelity — must stay intact

- Cult.fit brand colours and logo
- Cult.fit's energetic tone of voice
- Existing membership/class-booking interaction patterns
- Existing fitness-tracking UI conventions

**Independently audited 26 Sep** by a brand-compliance pass (all locked rules, palette traceability, copy tone, contrast fixes) — result: **Pass, no issues found.** See `Repo/brief/CONTRAST-AUDIT.md` for the accessibility half of that audit (now covers both the original 6 screens and the new onboarding sequence — see below).

## Open to redesign

- Therapist discovery & booking flow
- Mood/wellness tracking UI
- How mental-health content is visually distinguished from physical-fitness content

## Round 2 judged criteria (write toward these now, don't bolt them on later)

1. Research into mental-health-UI-specific sensitivities (privacy, stigma, tone) vs. general fitness apps
2. Colour-scheme rationale for a calming, non-clinical, non-alarming feel
3. How attention is managed for a user who may be in a vulnerable state — no overstimulation
4. Accessibility for anxiety, cognitive-load sensitivity, visual impairment — **now backed by two real measured WCAG contrast audits (original 6 screens + onboarding), plus real Playwright keyboard-operability testing, not assertions**
5. Userbase identification — age groups, first-time therapy seekers vs. existing Cult.fit members — and design decisions tied to that profile

Plus the standing rubric: Problem Understanding, Creative Innovation, User-Centric Design, Visual Excellence, Solution Viability, Final Presentation. Full mapping in `Repo/brief/round-2-prep.md`.

## Real brand research (pulled 26 Sep, see `Repo/brief/research.md`)

Cult.fit's actual design system is called **Aurora**: bold/energetic/immersive, dark-theme-primary, glassmorphic surfaces, a dynamic aurora-style animated background, and — critically — **it already runs 4 different colour themes across 8+ products.** Palette per Brandfetch/design.cult.fit: Black, White, Yellow, Blue, Pink, plus three gradients (Golden Hour, Daylight, **Midnight**) and status colours (positive/neutral/awaiting/error). Primary accent commonly cited as a burnt-sienna/coral `#F06055`.

**The actual design problem, stated plainly:** cult.fit's native visual language is loud and energetic — right for a workout, wrong for someone booking a first therapy session. The brief is explicitly judging whether you notice this and solve it *on-brand*, not by inventing a foreign palette.

**Superseded 26 Sep, v2 (see `Repo/design/DIRECTION.md`):** the original plan here was a 5th, dimmed "Midnight" Aurora theme. Once Love sent real design references (vibebevvy.com, habitsupps.com, vibrant.noomoagency.com, and several mental-health-app mockups), the direction shifted to something better-grounded: warm rather than dark. It pulls forward Aurora's own **Yellow**, **Pink**, and **Golden Hour**-gradient logic into a soft gradient-mesh background (peach → lavender → pale pink) with frosted glassmorphic cards — Aurora's own documented visual language, just used warm instead of dark — plus one original mascot built from Aurora's circular/soft-rounded logomark geometry, and coral reserved for CTAs only. Still on-brand, still answers judged criterion #2, but matches Love's actual taste instead of a generic "calm = muted" assumption.

## Screens built (final) — all in `Repo/design/`

All four required screens plus two context/comparison screens, built as real HTML/CSS and rendered to PNG: therapist discovery, booking confirmation (post-confirm, explicit privacy line), mood-tracking dashboard (icon-based mood, arc trend, one suggestion, no streaks), content/resources (organised by concern, no gamification), plus the existing-Fitness-vs-Faye-tab comparison pair. A real WCAG contrast audit (`Repo/brief/CONTRAST-AUDIT.md`) found and fixed two genuine failures (CTA button text, therapist-card badge text) with a darker on-brand shade — everything else already passed.

**Clickable prototype — built, then removed:** an experimental phone-frame tap-through prototype was built (real tap-through navigation across the whole flow, keyboard-accessible, a judge-convenience "jump to any screen" strip, reduced-motion support with a genuine CSS-ordering bug found and fixed, 3 added onboarding screens ahead of the required flow built on HERMES's copy, verified with Playwright — no dead clicks or console errors). It was then **deliberately removed** from the repo on 26 Sep so it wouldn't be mistaken for a submitted or functional screen; its onboarding contrast/keyboard findings are preserved as a labeled historical appendix in `Repo/brief/CONTRAST-AUDIT.md`. What actually ships is `design/screens.html` + the README screenshots.

**Brand-fidelity audit:** a dedicated compliance pass checked every shipped file against the locked rules above (palette traceability, no star ratings, icon-based mood not numeric, no streaks in Faye section, existing Fitness screen untouched, copy tone per screen) — **Pass**, no issues.

**`Repo/brief/WORKFLOW.md`** is the consolidated checklist for what's done, what's open, and the exact push-blocker fix.

## Full app concept — beyond the graded 4 screens (new, 26 Sep)

At Love's request, the concept extends beyond the four graded screens through MIDAS, HERMES, ATELIER, and Lego reviews. The latest pass also reconciled overlapping work from Claude and Codex. The current reviewed files live in `Repo/product-concept/`; they remain proposals until the evidence gates in the roadmap are met.

**Business verdict:** therapy economics are unproven for Cult.fit. The ₹1,200 price, 25% take rate, contribution estimate, member conversion, and employer channel are scenarios to test, not company data or a demonstrated growth engine. A live pilot requires provider/legal clearance and measured demand and contribution. See `Repo/product-concept/01-MIDAS-business-model.md`.

**Chain summary, each gating the next:**
- **`01-MIDAS-business-model.md`** — scenario economics, channel hypotheses, market-sizing arithmetic, and a provider/legal review gate. Public sources do not establish Cult.fit member conversion, actual therapist supply, contribution, or the complete obligations of every provider category. The DPDP analysis now distinguishes withdrawal, assessed erasure, and separate erasure requests using the official Act.
- **`02-HERMES-offer-and-persona.md`** — persona "Ananya" (24, Bangalore, 8-month Cult.fit member, three named specific fears — including the fear that finding a session on a shared card gets noticed by parents), Schwartz awareness stage, full Hormozi Value Equation breakdown, the "Notice → Name → Nudge" non-gamified habit loop, and verbatim onboarding copy (every line under 15 words, zero em dashes, per HERMES's own non-negotiable rules). Named the paid product **"Steady"** — explicitly flagged as an untested naming bet, not a decided fact.
- **`03-ATELIER-feature-map.md`** — proposed therapist details, billing, a separately accessible crisis-help route, and provider-switch consent. Between-session messaging is deferred because coverage, response time, provider workload, and documentation are unbuilt. No mood-triggered clinical inference or paid-session upsell.
- **`04-Lego-technical-and-compliance.md`** — proposed consent/data contract and integration questions. Payment statement wording remains unverified across rails; crisis contacts need a maintained owner-verified list; KIRAN status is unresolved. The DPDP Act also requires assessed erasure on withdrawal unless retention is necessary for law, alongside a separate erasure-request route. No existing Cult.fit service integration is verified.
- **`00-RESEARCH-PILLARS-INDEX.md`** — the synthesis map tying all of the above together plus the original brand research and accessibility audits, organised by 6 real pillars (market/regulatory, unit economics, persona/positioning, product/interaction design, technical/compliance, accessibility) rather than one section per document. Surfaces the real cross-pillar dependency chains (e.g. HERMES's named parent-privacy fear → ATELIER's payment-descriptor UI claim → Lego's finding that the claim is actually unconfirmed) and closes a **9-item risk register**, each tagged with an owner and severity. None of the 9 block the already-content-complete Round 1 submission — they're build-phase or Round-2-presentation items. The most important process finding: MIDAS's own document says legal clearance should gate everything downstream, but HERMES/ATELIER/Lego were built on MIDAS's 🟡/🟠-graded assumptions without that clearance — flagged as the single biggest risk if this ever becomes a real build, not a hackathon-blocking issue.

**Accessibility work:** measured contrast audits found and fixed the original screen failures plus three onboarding failures. Browser checks verified the consent toggle and, after a follow-up fix, the mood radio group now uses one Tab stop, arrow-key selection, and focus transfer. See `Repo/brief/CONTRAST-AUDIT.md`.

**`06-PRODUCT-SPEC-AND-ROADMAP.md`** adds a practical first-session prep card, a privacy receipt, discreet reminder controls, a consent/data contract, and staged evidence gates. Bee (CycleSync) contributes the pattern of consent-aware tracking and care handoff; Relationship AI contributes a pattern for optional reflection prompts. Neither product's intimate data or clinical claims transfer into Kalakriti.

## Genuine tie-in to existing work

Being straight about this rather than forcing a connection: most of what's in the vault doesn't touch mental-health/therapy-booking. FROSTD is an alcohol brand (opposite valence). Relationship AI is attraction/dating, not clinical wellbeing. Popcorn is unrelated.

**What actually transfers, for real:**
- **[[Projects/CycleSync/CycleSync|Bee (CycleSync)]]** — an active SIH-track wellness product: cycle-aware fitness/nutrition, built by a real team, with a completed **Product Experience Blueprint** (onboarding, screens, AI explainer, care handoff, Learn system, freemium boundaries), an **Ideal Consumer persona (Shanaya)**, and documented non-clinical tone/design-language work. The *pattern language* transfers directly: symptom-tracking dashboard → mood-tracking dashboard; care handoff → therapist discovery/booking; Learn system → content/resource screen. Not copying Bee's content into Kalakriti — reusing the design thinking that already solved "how do you track a personal, sensitive state without feeling clinical."
- **MIDAS** (business model, unit economics), **HERMES** (persona, copy, funnels, naming), **ATELIER** (interface, typography, motion, product copy), and **Lego** (web engineering, accessibility, deployment, compliance) — all four house agents now have real, dated work product in this project, not just a routing mention.

## Repo — content done, push still blocked

**Confirmed directly again, 26 Sep (this session):** `github.com/loveluthra/kalakriti` is public and reachable, but genuinely has **zero commits** — nothing has ever been pushed to it. The earlier confusion in this file about a 7-commit-vs-14-commit bundle mismatch was never independently verified and has been dropped per `Repo/brief/WORKFLOW.md` §3 — there is no history to reconcile, this is a first push, not a merge.

Every file under `Repo/` (`brief/`, `design/`, `product-concept/`, plus the root `README.md`/`CLAUDE.md`) is the current, correct, complete content and is ready to ship as-is.

**Push status:** every AI session that has tried this — Claude (this one, and an earlier one) and Codex — has been refused GitHub write access to this repo (an auth/safety gate on the assistant's side, not a GitHub permissions problem). **This has to be a human action.** Exact terminal commands, plus a no-terminal GitHub-web-UI fallback, are in `Repo/brief/WORKFLOW.md` §3.

## Open decisions (Love's call)

- Push the repo — see `Repo/brief/WORKFLOW.md` §3 for the exact terminal commands (or the no-terminal GitHub web-UI option). This is the single blocking item for Round 1.
- Teammates' GitHub usernames, for collaborator access once push works.
- React to the final screens/prototype — no sign-off given yet.
- Confirm or override the userbase call in `Repo/brief/screen-flow.md` (currently: first-time therapy seekers, urban 20s, existing Cult.fit members as secondary).
- Decide what to do with the product-concept work for Round 2 — it's real and substantive but goes well beyond what's judged; worth a conscious call on how much of it (if any) belongs in a Round 2 presentation vs. staying as background depth.
- "Steady" as the paid product name is explicitly flagged as untested by HERMES — worth a real gut-check before treating it as final anywhere it gets reused.
