---
type: spec
project: Kalakriti
updated: 2026-09-26
---
# Screen flow — content & IA spec (pre-visual)

**Historical working note:** use `../Repo/brief/screen-flow.md` for the current graded screen spec. The warm Aurora direction superseded the Midnight proposal, and the current flow does not use unsupported social proof or mood-triggered paid-session prompts.

Locked deliverable: therapist discovery → booking confirmation → mood-tracking dashboard → content/resource screen. This spec fixes *what's on each screen and why* before any pixels, so the design phase (once Love sends inspiration) is fast execution, not re-deciding structure.

## Entry point

New nav destination inside the existing Cult.fit tab bar (alongside Fitness, Cult Transform, etc.) — visually distinguished per the "open to redesign" item, using the warm Aurora-derived direction documented in `../Repo/design/DIRECTION.md` so the section reads as "same app, calmer room" the instant it opens. This single transition *is* the answer to "how mental-health content is visually distinguished from physical-fitness content" — a theme shift on entry, not a different app.

## Screen 1 — Therapist discovery

- Search/filter bar: concern (anxiety, stress, relationships, sleep...), language spoken, gender preference, availability (today / this week) — filters as chips, not a form.
- Therapist cards: photo (natural, still — see photography note in Research), name, credentials line, 1-line specialisation, next available slot, session price, a trust badge row (verified credential, years practising) reusing cult.fit's existing trainer-verification visual language so it doesn't need to be invented from scratch.
- No star-rating/review-count front and center — reviews on a public profile for a therapist read as a privacy problem (a client publicly "reviewing" therapy). Omit unsupported member-based social proof — flag this explicitly in Round 2 as a deliberate trust-without-exposure decision.
- Progressive disclosure: tapping a card expands in place (bottom sheet) rather than a full navigation away, keeping the browsing context — lower cognitive load than a stack of new screens.

## Screen 2 — Booking confirmation

- Single-column summary: therapist, date/time, session type (video/in-person if applicable), price, cancellation policy stated plainly (not buried in T&Cs) — cancellation anxiety is a real first-time-user blocker, address it on-screen.
- One primary CTA ("Confirm booking"), one secondary (back to edit) — no more than these two actions on the screen.
- Reuses existing membership/class-booking confirmation pattern from cult.fit fitness (brand-fidelity requirement) — same component, different content, so it feels instantly familiar to existing members.
- Post-confirmation state: a calm confirmation screen with what happens next (reminder will be sent, how to reschedule, a short privacy note on who can see this booking) — not a generic "success!" toast, because for a first therapy booking the anxiety isn't "did it work" but "who knows about this."

## Screen 3 — Mood-tracking dashboard

- Daily check-in: one-tap mood log (small set of expressive icons, not a 1–10 numeric scale — numeric scoring reads clinical/diagnostic, which the brief explicitly wants avoided) plus an optional one-line note.
- Trend view: simple weekly line, not a dense chart — matches the "avoid overstimulation" criterion directly.
- One adaptive surface per day: a single suggested action (a guided breathing session, a relevant article, selected from a concern the member explicitly chose, without treating a mood trend as clinical evidence or a paid-session trigger) — never a wall of recommendations.
- Pattern reused from Bee's symptom-tracking work (see [[Projects/Kalakriti/Agent Files/Research|Research]] §4): log fast → see trend → one suggestion, not a dashboard of ten metrics.

## Screen 4 — Content/resource screen

- Organised by concern (not by content type) — mirrors the discovery filters from Screen 1 so the taxonomy is consistent across the section.
- Mix of formats (short read, audio, guided exercise) but each card states duration up front — respects a user who may have limited attention/energy.
- Visually the calmest screen in the flow — this is where the "Learn system" pattern from Bee applies most directly: educational without being preachy, no gamification badges/streaks (those read as pressure, wrong tone for mental health even though cult.fit uses streaks elsewhere for fitness — an explicit, callable-out exception to "reuse existing UI conventions," worth stating plainly in Round 2 rather than hiding).

## Accessibility checklist (Round 2 criterion #4 — build in now, don't retrofit)

- Minimum tap target sizing and spacing generous enough for a shaky/distracted tap, not just compliant minimums.
- No auto-advancing carousels or timed content anywhere in this section.
- Every icon-only control has a text label available (not just on hover/long-press).
- Reduced-motion respected — the Aurora background animation and card transitions should have a calm/static fallback, same instinct already applied in the vault's own Bee icon motion work (hover/tilt with reduced-motion support).
- Copy at a plain-language reading level throughout; no clinical/diagnostic terminology in user-facing copy (route through HERMES for tone pass).

## Userbase framing to state explicitly in Round 2

Primary: first-time therapy seekers, urban 20-somethings, likely renters/students/early-career — the segment for whom both "therapy" and "on-demand booking of it" are being encountered as new concepts together. Secondary: existing Cult.fit members cross-shopping. Design decisions above (chip filters over forms, one-tap mood icons over numeric scores, no review counts on therapists, no streaks in this section) all trace back to this primary segment's likely anxieties (fear of exposure, fear of a diagnostic-feeling product, low tolerance for cognitive load in a vulnerable moment) — state that traceability out loud in the presentation, since "design decisions tied to that profile" is a named judging line.
