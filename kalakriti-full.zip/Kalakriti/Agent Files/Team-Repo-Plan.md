---
type: plan
project: Kalakriti
updated: 2026-09-26
---
# Team collaboration — shared repo plan

Goal stated by Love: teammates need to work in parallel, in a shared file system, with each teammate's own LLM (Claude, ChatGPT, Gemini) able to read context and start work without a briefing call.

## Reality check on the ask

A GitHub repo gets you real parallel collaboration (branches, PRs, everyone's changes visible, works with any teammate's tool of choice). It does **not** give different LLMs a live shared brain mid-session — Claude, ChatGPT and Gemini don't read each other's working memory. What actually makes "their LLMs read and start work" true is a well-written root document every model is pointed at: whoever opens the repo, human or AI, reads one file and has full context. That's the plan below, not anything fancier.

## Structure

```
kalakriti-cultfit/
├── README.md              ← human-facing: what this is, current status, how to view the prototype/screenshots
├── CLAUDE.md / AGENTS.md  ← LLM-facing: brief, constraints, decisions already locked, where NOT to re-litigate
├── brief/
│   ├── rulebook-summary.md
│   ├── research.md         (from Research.md above)
│   └── screen-flow.md       (from Screen-Flow.md above)
├── design/                 ← Figma/Canva links once visual phase starts; exported screenshots for the README
└── deck/                   ← company overview deck if this theme ends up needing one (Cult.fit scenario doesn't; only FinTech does per the rulebook — confirm before spending time here)
```

The `CLAUDE.md`/`AGENTS.md` file is the actual mechanism: it states the locked scope (theme + scenario can't change), the brand-fidelity constraints, the decisions already made here (userbase, theme resolution, screen content), and a note like "if you're an LLM picking this up cold, read brief/ in full before proposing changes to IA or copy — don't restart discovery." Any teammate can hand this repo to their own model and get a coherent continuation instead of a cold start.

## What I can't do unilaterally

I don't have a "create a new GitHub repo" tool in this session, and creating one on your behalf without your account would put it under the wrong owner anyway — organiser rules require the link to be public and yours/your team's to own. Two options:

1. **You create an empty public repo** (2 minutes, e.g. `kalakriti-cultfit` under your GitHub account or a team account) and give me push access — I populate it from here in one pass.
2. **You already have one** for this — point me at it and I do the same.

Either way I still need: teammates' GitHub usernames (for repo collaborator access — this is separate from "their LLM reading it," which needs no permission at all once the repo is public) and whether this ships under your personal GitHub or a team-name account (matters for the README byline and for how the organisers will attribute it).

## Submission-format compliance

Rulebook allows either a public design-tool link (Figma/Canva/etc.) or a public GitHub repo with screenshots in the README. Given the team-parallel-work requirement, GitHub is the better fit for *process*; but the actual visual deliverable can still live as a Figma file linked from the README once the design phase starts — the two aren't exclusive. Recommend: GitHub repo as the working hub and submission vehicle, README embeds screenshots + a Figma link if one exists by submission time. Whichever it is, double-check it's actually reachable in an incognito window before submitting — the rulebook is explicit that a private link gets skipped with no recourse.
