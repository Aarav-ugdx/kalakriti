---
type: research
project: Kalakriti
updated: 2026-09-26
---
# Research — Cult.fit mental-health pivot

**Historical research note:** the early Midnight direction below was superseded by the warm Aurora direction in `../Repo/design/DIRECTION.md`. Current interaction decisions live in `../Repo/brief/screen-flow.md`; current product and evidence gates live in `../Repo/product-concept/`.

## 1. Cult.fit's real brand system

- **Design system name: Aurora.** Principles: Bold/Energetic/Immersive, Intent-Driven, Simply Efficient, Break the Mould. Built Atomic-Design style (sub-atomic particles → atoms → molecules → organisms → templates). Rebuilt in Flutter specifically because glassmorphism/blur at their scale broke React Native performance — a real signal that heavy blur/motion is core to the identity, not decoration.
- **Logomark:** circular, soft rounded edges, "symmetry & balance" — chosen deliberately to read as inclusive/friendly/warm, not aggressive. This matters: the brand's own stated intent for its mark is warmth, even though the product surface (workout content) reads high-energy. Gives real license to lean warmer for the mental-health surface without breaking brand logic.
- **Palette:** Black, White, Yellow, Blue, Pink as primary brand colours; three gradients — Golden Hour, Daylight, **Midnight**; dedicated status colours (positive/neutral/awaiting/error). Commonly cited accent `#F06055` (coral/burnt-sienna). Aurora already runs **4 distinct colour themes across 8+ intent products** — precedent for a 5th, calmer theme rather than a one-off reskin.
- **Typography:** two explicit modes — task-focused (fast comprehension, e.g. booking/checkout) vs. emotive (provoke reaction, e.g. marketing/content). A mental-health flow should borrow the task-focused mode for booking steps and a *toned-down* emotive mode for content/resources — not the high-adrenaline version used for class marketing.
- **Photography:** real/bold/energetic, action shots, explicitly rejects "posed, low energy, flat, stockish." For a therapy context this is a real tension — action photography of a person mid-workout is wrong tone for "find a therapist." Recommend: keep the *authenticity* principle (real people, not stock-therapy stethoscope-and-couch imagery) but drop the "mid-action" requirement — a still, natural portrait of a real-feeling person is authentic without being high-energy.
- **Layout:** 12-column mobile grid, consistent spacing scale — reuse as-is, no reason to deviate.
- Sources: [Aurora design language](https://blog.cult.fit/posts/aurora-design), [cult.fit brand assets](https://brandfetch.com/cult.fit), [design.cult.fit](https://design.cult.fit/popup/)

## 2. The core design tension (this is the actual brief)

Cult.fit's native mode is loud, dark, high-motion, red/coral-accented, action-photographed — tuned for "get pumped for a workout." Someone opening a mental-health section is often the opposite: possibly anxious, possibly booking their first-ever therapy session, wants to feel steadied, not activated. Round 2 criterion #2 and #3 are explicitly judging whether the team notices and resolves this. The lazy answer is "we used pastel colors and rounded fonts" — generic wellness-app cosplay that abandons brand fidelity. The credible answer uses Aurora's own stated flexibility (multiple themes, a Midnight gradient, task-focused type mode, a logomark whose intent is already "warm") to produce a fifth Aurora theme: same bones, dialled amplitude — dimmed glassmorphism, slower/softer motion curves, Midnight-based gradient instead of Daylight/Golden Hour, coral used only as a small accent (CTAs, not backgrounds), task-focused type throughout.

## 3. Competitor / pattern scan — mental-health & wellness apps

- **Wysa** (AI-first mental health chat + human therapist handoff): uses a calm mascot/companion metaphor to soften a clinical topic, low-saturation palette, conversational (not form-heavy) onboarding, explicit crisis-escalation paths built into the flow rather than hidden in settings.
- **BetterHelp / Calm / general wellness-app UX literature:** consistent patterns worth reusing — (a) color psychology: cool blues/greens/soft neutrals read as calming, saturated warm reds/oranges read as urgent/alarming (direct implication for how far coral gets dialled back); (b) progressive disclosure in onboarding — one question at a time, not a form wall, because a user in a vulnerable state disengages from long forms; (c) plain-language copy over clinical terminology; (d) generous whitespace and slower transition timing than a fitness app's UI to avoid a "rushed" feeling.
- Sources: [UXmatters — color psychology for health/wellness apps](https://www.uxmatters.com/mt/archives/2024/07/leveraging-the-psychology-of-color-in-ux-design-for-health-and-wellness-apps.php), [Gapsy — mental health app design guide](https://gapsystudio.com/blog/mental-health-app-design/), [Gapsy — mental health website design](https://gapsystudio.com/blog/mental-health-website-design/), [Pixelbrainy — building an app like Wysa](https://www.pixelbrainy.com/blog/build-ai-mental-health-and-wellness-app-like-wysa)

## 4. Reused internal pattern language — Bee (CycleSync)

Bee's completed **Product Experience Blueprint** already solved a structurally similar problem: tracking a personal, sometimes sensitive, cyclical state (symptoms) and adapting recommendations to it, without turning the product clinical or alarming. Directly transferable pattern language (not content — Bee's actual copy/brand stays Bee's):
- Symptom-tracking dashboard → **mood-tracking dashboard**: same "log a personal state quickly, see a trend, get one adaptive suggestion" shape.
- Care handoff (when to point a user to a professional) → **therapist discovery/booking**: same "this is a moment where the product should get out of the way and connect a human," same tone requirement (not alarmist, not dismissive).
- Learn system (educational content without being preachy) → **content/resource screen**.
- Bee's non-clinical tone research and freemium/boundary thinking (what the product will and won't claim to diagnose) is directly reusable for Round 2 criterion #1 (privacy/stigma/tone sensitivities) — Bee already worked through the "we are not a medical device, be careful with claims" boundary for a different sensitive-health surface.

## 5. Userbase call (see [[Projects/Kalakriti/Agent Files/Screen-Flow|Screen-Flow]] for how this drives the design)

Primary: first-time therapy seekers, urban 20s renters — the segment most likely to be discovering both "community mental-health support" and "on-demand booking" as new concepts simultaneously (mirrors Tata Power scenario's "unfamiliar concept, explain visually" problem, one theme over). Secondary: existing Cult.fit members cross-shopping from fitness into mental health — for them the design should visually confirm "same app, new section" rather than feel like a bolt-on. Older/less tech-literate renters are named in the brief for Tata Power's scenario, not Cult.fit's — but accessibility for anxiety and cognitive load (explicitly named for Cult.fit) still means: no dense text walls, no more than one decision per screen in the booking flow, visible progress indicator, and an always-visible way out/back.
