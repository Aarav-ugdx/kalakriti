# Round 2 prep (only relevant if shortlisted)

Round 2 is a live presentation defending the Round 1 submission. This maps each judged criterion from the rulebook to what's actually in this repo, so the presentation is assembling existing answers, not writing new ones under time pressure on the 29th.

## 1. "Research into sensitivities specific to mental health UI (privacy, stigma, tone) vs. general fitness apps"

Point to: `brief/research.md` §2–3. The concrete decisions that came out of this research, visible in the screens:
- No star ratings/review counts on therapist profiles (privacy — a public review of a therapist exposes the client)
- The booking-confirmation privacy line: "won't appear in shared activity, streaks, or your Cult.fit profile feed"
- No streaks/gamification anywhere in the Mind section, even though the existing Fitness tab uses them (see the `00a`/`00b` comparison)
- Plain-language cancellation policy shown up front, not buried — first-time-booking anxiety is about commitment, address it before it's asked

## 2. "Colour scheme rationale for a calming, non-clinical, non-alarming feel"

Point to: `design/DIRECTION.md`. The rationale in one line: **we didn't invent a new palette — we pulled Aurora's own Yellow/Pink/Golden-Hour gradient logic forward and used it warm instead of dark, with coral demoted to CTA-only.** This is a stronger answer than "we made it blue and soft" because it's traceable to the existing brand system, not an outside wellness-app aesthetic bolted on. Show the `00a`/`00b` comparison to make the shift visible in one glance.

## 3. "How the design manages attention for a user who may be in a vulnerable state, avoiding overstimulation"

Concrete evidence in the screens: filter/concern selection is tap-chips, not a multi-field form (Screen 1); the booking flow has exactly one primary + one secondary action per screen, never more; the mood dashboard shows one adaptive suggestion, never a list of recommendations; the resource screen states each item's time cost before you tap in, so there's no open-ended commitment.

## 4. "Accessibility for users with anxiety, cognitive load sensitivity, visual impairments"

Point to: `brief/screen-flow.md`, accessibility checklist. Headline items: generous tap targets, no auto-advancing/timed content anywhere in this section, icon controls carry text labels, reduced-motion fallback for the gradient/glassmorphism, plain-language copy throughout (no clinical/diagnostic terms in user-facing text).

## 5. "Userbase identification — age groups, first-time therapy seekers vs. existing Cult.fit members — and design decisions tied to that profile"

Primary: first-time therapy seekers, urban 20-somethings (renters/students/early-career) — encountering both "therapy" and "on-demand booking of it" as new concepts together. Secondary: existing Cult.fit members cross-shopping from fitness. Trace every decision above back to this explicitly when presenting — that traceability is what's actually being graded here, not the persona statement on its own.

## Standing rubric — where each lives

- **Problem Understanding** → `brief/rulebook-summary.md` + the design tension named in `brief/research.md` §2
- **Creative Innovation** → the Aurora-warm resolution (not a generic wellness reskin, not a dark reskin either) + the original mascot built from the existing logomark geometry
- **User-Centric Design** → `brief/screen-flow.md`, every "why" annotation
- **Visual Excellence** → the built screens themselves + the `00a`/`00b` comparison
- **Solution Viability** → cite the existing membership/booking pattern reuse (this isn't a new app, it's four screens inside infrastructure Cult.fit already has) and the deliberate scope discipline (no new backend concepts invented — booking, tracking, and content are all patterns Cult.fit's fitness side already runs)
- **Final Presentation** → walk `00a → 00b →` the four required screens in that order live; it tells the story in the same sequence a real user would experience it

## Open — needs Love/team input before Round 2, not before Round 1

- Real photography to replace the flat gradient avatar placeholders, if there's time
- Whether to record a short click-through video in addition to static screens (not required, but strengthens "Final Presentation")
