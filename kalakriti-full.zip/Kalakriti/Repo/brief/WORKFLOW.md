# WORKFLOW — read this first

Single source of truth for "what do I do right now." If you're a teammate, or a teammate's AI assistant (Claude/ChatGPT/Gemini/whatever), landing here under time pressure: this doc tells you exactly where things stand and what's left. Everything else in this repo is reference material this doc points into — don't duplicate it here, and don't re-derive it from scratch.

**Deadline: Round 1 closes 12:00 IST, 27 Sep 2026.** Submission is via the organisers' Forms link, pointing at this repo.

---

## 1. Guardrails — confirm these before you touch anything

These are locked. Full reasoning is in `CLAUDE.md` and `brief/`. If you disagree with one, say so explicitly with reasoning in a commit message or to Love directly — never silently override it.

- [ ] Theme and scenario are locked: Health & Well-Being, Scenario 2 (Cult.fit mental-health pivot). Cannot change for either round.
- [ ] Screen order is locked: therapist discovery → booking confirmation → mood-tracking dashboard → content/resource screen. Don't reorder or drop one.
- [ ] Brand fidelity is non-negotiable: Cult.fit's colours/logo, energetic tone of voice, existing membership/class-booking patterns, and existing fitness-tracking UI conventions must stay recognisable. This is a redesign living inside Cult.fit's shell, not a from-scratch wellness app.
- [ ] Visual direction is locked at v2 (warm Aurora-derived gradient-mesh + glassmorphism, coral reserved for primary CTAs only) — see `design/DIRECTION.md`. Don't propose reverting to the earlier dark "Midnight" direction.
- [ ] No star ratings/review counts on therapist profiles, no numeric 1–10 mood scale, no streaks/gamification in the Faye section — all three are deliberate, named exceptions to how Cult.fit normally works. Don't "fix" them.
- [ ] The repo must stay **public** through submission and judging. A private repo is an automatic disqualification per the rulebook — this is the single easiest way to fail this competition by accident.

If you're about to add content, copy, or a screen: check `brief/screen-flow.md` and `brief/research.md` first. If you're about to touch visual style: check `design/DIRECTION.md` first.

---

## 2. Where things actually stand right now

**Done:**
- [x] Brief, brand research, and screen-flow content spec (`brief/research.md`, `brief/screen-flow.md`)
- [x] Rulebook summary and locked scope (`brief/rulebook-summary.md`)
- [x] Visual direction locked and documented (`design/DIRECTION.md`)
- [x] Four required screens built + existing-fitness-vs-Faye-tab comparison (`design/screens.html`, `design/screens/*.png`)
- [x] WCAG contrast audit run with real computed ratios, two genuine failures found and fixed (`brief/CONTRAST-AUDIT.md`)
- [x] Round 2 prep doc mapping every judging criterion to what's already in the repo (`brief/round-2-prep.md`)
- [x] README with screenshots, in the format the rulebook accepts as a standalone submission
- [x] The annotated `design/screens.html` and the README PNGs are the submission artifacts. The experimental clickable prototype and its QA captures were removed from this repo to prevent them being mistaken for submitted or functional screens.
- [x] The original screen contrast audit is in `brief/CONTRAST-AUDIT.md`. Its onboarding appendix is labeled historical because that experimental prototype was removed.
- [x] Renamed the section brand from "Mind" to **"Faye"** (26 Sep) — nav label, mascot, topbar lockup, and every doc reference updated (last stragglers in `product-concept/08-CULTFIT-DESIGN-RESEARCH.md` and a `screens.html` comment fixed 26 Sep); screenshots regenerated to match. See `CLAUDE.md` decision 6 and `design/BRAND-AND-EXPERIENCE.md`.
- [x] Added `design/STITCH-PROMPTS.md` — ready-to-paste Google Stitch prompts for anyone exploring visual variations, built from the same locked color/copy/exclusion rules as `screens.html`.

**Local review completed:**
- [x] Reviewed the rendered annotated screens against section 1. The Fitness home shown here is an illustrative recreation, not a captured live Cult.fit screen.
- [x] Added planning-only branding and UI/UX improvement documents; no new screen is included in the current submission.

**Still open, not yet started:**
- [ ] **Push this repo to GitHub — see section 3. This is the single blocking item for Round 1.** Verified directly (26 Sep, ~20:40 IST): `github.com/loveluthra/kalakriti` exists, is public, and is completely empty — zero commits, no README rendering. Nothing has ever been pushed to it. Everything else in this checklist is finished and sitting in this working copy; none of it is visible to the organisers until this one step happens.
- [ ] Add teammates as collaborators — blocked on Love getting their GitHub handles. Update the "Team" section in `README.md` once you have them.
- [ ] Love's reaction/sign-off on the current visual direction and the Faye rename — get that before Round 1 submission if at all possible; if time runs out, submit as-is rather than missing the deadline over it.

---

## 3. The active blocker — this repo has never been pushed to GitHub

**Earlier drafts of this section described a confusing 7-commit-vs-14-commit bundle-reconciliation problem. That was never independently verified and is dropped — it doesn't matter now.** What's actually true, checked directly against the live GitHub page on 26 Sep: `github.com/loveluthra/kalakriti` is public and reachable, but has **zero commits** — it has never received a push, from any bundle, any history, anything. There is no history to "reconcile." This is a first push, not a merge.

This working copy (inside the ACHERON Obsidian vault, at `Projects/Kalakriti/Repo/`) is the current, complete, correct content — every file in `brief/`, `design/`, and `product-concept/`, plus the regenerated screenshots. It is **not itself a git repo with a remote** — it lives inside the vault's own private git history, which must never be pushed publicly (it contains unrelated personal material). Getting this specific folder's content onto the public `kalakriti` GitHub repo is a **copy + fresh push**, not a push of the vault repo.

**An AI assistant with GitHub write access attempted this push directly on 26 Sep and was blocked by a platform-side safety gate** (not a GitHub permissions issue — the assistant's own GitHub connector is authenticated as `loveluthra` with what should be sufficient access, but the push action itself was refused by an auto-mode classifier before it reached GitHub). That means **a human has to do this last step.** Two ways, fastest first:

- [ ] **Option A — terminal, from Love's own machine (recommended, preserves proper history):**
  ```
  cd path/to/Projects/Kalakriti/Repo
  git init
  git add -A
  git commit -m "Initial public submission — Kalakriti, Cult.fit Faye"
  git branch -M main
  git remote add origin https://github.com/loveluthra/kalakriti.git
  git push -u origin main
  ```
  Needs `git` installed and already authenticated to `loveluthra`'s GitHub (existing `gh auth login`, SSH key, or credential manager — most Mac setups already have one of these for an account with 3 existing public repos).
- [ ] **Option B — GitHub web UI, no terminal needed:** open `https://github.com/loveluthra/kalakriti`, use "uploading an existing file," and drag the entire `brief/`, `design/`, `product-concept/` folders plus the three root files (`README.md`, `CLAUDE.md`, this file's parent) in — modern GitHub's drag-and-drop preserves folder structure. Slower for the image-heavy `design/screens/` folder; Option A is cleaner if a terminal is available at all.
- [ ] After either option: confirm the public README and image links load while **signed out / in an incognito window** — the rulebook explicitly disqualifies an unreachable or private link, so this check is not optional.
- [ ] If a teammate or a differently-configured AI session has GitHub push access that this session didn't, that's the faster path — don't block on Option A/B if that's available.

---

## 4. Sequence from now to the 12:00 IST deadline

1. [ ] Push this working copy to `github.com/loveluthra/kalakriti` for the first time (section 3 — Option A or B) and verify it loads signed-out.
2. [ ] Confirm the repo is genuinely **public and reachable** — open `github.com/loveluthra/kalakriti` in an incognito/private browser window (not logged in) and verify the README and screenshots render. The rulebook explicitly disqualifies unreachable or private links — this check is not optional.
3. [ ] Check the annotated screen flow and brand-fidelity review, then do a final skim of README claims against what is actually in the repo.
4. [ ] Submit the GitHub repo URL via the organisers' Forms link.
5. [ ] Done for Round 1. Don't keep tinkering with content after submission unless something is actually broken — Round 2 prep is separate (section 5).

---

## 5. If shortlisted — Round 2

Don't duplicate Round 2 prep here. It's already mapped: `brief/round-2-prep.md` maps every Round 2 judging criterion (sensitivities research, colour rationale, attention management, accessibility, userbase identification, and the standing rubric) to exactly what's already in this repo, so the 29 Sep presentation is assembling existing answers, not writing new ones under time pressure.

- [ ] Confirm `brief/round-2-prep.md` is still current against whatever landed after Round 1 (prototype, brand-fidelity audit, any visual revisions from Love's feedback).
- [ ] If real photography replaces the placeholder avatars, or a click-through video gets recorded (both listed as open/optional in `brief/round-2-prep.md`), note it there — don't let Round 2 prep drift out of sync with the actual repo.

---

## 6. For any teammate's AI assistant picking this up cold

Read `CLAUDE.md` first, in full, before proposing any change to scope, persona, screens, or visual direction. It contains the locked decisions and explicitly says not to relitigate them without cause — the "Guardrails" checklist in section 1 above is the fast version, but `CLAUDE.md` has the actual reasoning if you need it.

Source of truth, by topic:
- Rules/deadline/scope: `brief/rulebook-summary.md`
- Content/IA per screen: `brief/screen-flow.md`
- Brand research and design tension: `brief/research.md`
- Visual direction and rationale: `design/DIRECTION.md`
- Accessibility: `brief/CONTRAST-AUDIT.md`
- Round 2: `brief/round-2-prep.md`
- Current status and next action: this file

If something here looks stale (a checkbox that should be checked, a blocker that's already cleared), fix this file in the same commit as whatever cleared it — this doc is only useful if it stays accurate.
