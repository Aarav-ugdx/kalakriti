# References — every external source, link, and visual reference used in this project

Consolidated from every doc in this repo (`brief/`, `design/`, `product-concept/`) so they don't stay scattered across five files. Grouped by what they were used for, with which doc cites each one. Nothing here is invented — every link below is copy-pasted from an existing citation in this repo, cross-checked by grepping the actual files rather than reconstructed from memory.

## Visual/design direction references

These shaped `design/DIRECTION.md` and the warm-glassmorphic resolution built in `design/screens.html` / `design/prototype.html`.

| Reference | What it contributed | Status |
|---|---|---|
| **Mental-health app mockups** | The core precedent pattern actually copied: warm gradient-mesh backgrounds (purple→orange, peach→lavender), frosted glassmorphic cards, a small illustrated mascot carrying emotional tone, mood logged via a rainbow arc/icon chips instead of a number, pill-chip concern tagging. | **Not recoverable as files in this session** — these were sent as chat image uploads earlier in the project, before the point this session's file history goes back to. They are not present in this environment's upload folder. If you still have the originals, worth re-attaching and saving into `design/references/` for the record — right now the only trace of them is the written description in `DIRECTION.md`. |
| [vibebevvy.com](https://vibebevvy.com) | Jewel-tone-into-pastel palette, bold rounded friendly sans-serif type, hand-drawn ornamental touches, generous whitespace | Live site link, not saved as a screenshot in-repo |
| [vibrant.noomoagency.com](https://vibrant.noomoagency.com) | Confident high-contrast presentation; wellness made to feel current/interactive rather than clinical | Live site link, not saved as a screenshot in-repo |
| [habitsupps.com](https://habitsupps.com) | Restrained "science-backed but approachable" tone — the counterweight that kept the booking/checkout screens from over-playfulness | Live site link, not saved as a screenshot in-repo |

## Cult.fit brand system (Aurora) — source of truth for brand-fidelity rules

Cited in `brief/research.md` §1, underpins every locked brand-fidelity rule in `CLAUDE.md`.

- [Aurora design language — blog.cult.fit](https://blog.cult.fit/posts/aurora-design)
- [cult.fit brand assets — Brandfetch](https://brandfetch.com/cult.fit)
- [design.cult.fit](https://design.cult.fit/popup/)

## Competitor / UX pattern research

Cited in `brief/research.md` §3, informed the calm-not-clinical tone call and progressive-disclosure onboarding pattern.

- [UXmatters — color psychology in UX design for health & wellness apps](https://www.uxmatters.com/mt/archives/2024/07/leveraging-the-psychology-of-color-in-ux-design-for-health-and-wellness-apps.php)
- [Gapsy Studio — mental health app design guide](https://gapsystudio.com/blog/mental-health-app-design/)
- [Gapsy Studio — mental health website design](https://gapsystudio.com/blog/mental-health-website-design/)
- [Pixelbrainy — building an app like Wysa](https://www.pixelbrainy.com/blog/build-ai-mental-health-and-wellness-app-like-wysa)
- **Wysa** itself — cited by name (not a specific URL) as the calm-mascot/companion-metaphor and judgment-free-conversation-positioning precedent, referenced again in HERMES's and MIDAS's docs for its freemium/free-triage structure

## Regulatory & legal research (MIDAS — `product-concept/01-MIDAS-business-model.md`)

Real primary/secondary sources checked directly, not asserted from training-data recall — this is what backs the "doesn't work yet" verdict's regulatory constraints and the DPDP consent-architecture requirements Lego built on top of.

- [Telepsychiatry Operational Guidelines 2020 — NIMHANS PDF](https://nimhans.co.in/wp-content/uploads/2021/09/Telepsychiatry-Operational-Guidelines-2020.pdf)
- [Indian Journal of Psychiatry — commentary on TPG 2020](https://journals.lww.com/indianjpsychiatry/fulltext/2021/63010/telemedicine_practice_guidelines_of_india,_2020_.16.aspx)
- [Mental Healthcare Act 2017 — full text, indiacode.nic.in](https://www.indiacode.nic.in/bitstream/123456789/2249/1/A2017-10.pdf)
- [Legal Requirements for Online Therapy in India (2025) — lifehetu.com](https://www.lifehetu.com/blog/legal-requirements-for-online-therapy-india-2025)
- [Sense and Sensitivity: 'Sensitive' Information Under India's New Data Regime — SNR Law](https://www.snrlaw.in/sense-and-sensitivity-sensitive-information-under-indias-new-data-regime/) — the source that corrected MIDAS's own earlier wrong claim about DPDP and health data
- [DPDP Act 2023 Healthcare Compliance Checklist — ichelonconsulting.com](https://ichelonconsulting.com/insights/dpdp-act-2023-healthcare-compliance-checklist)
- **BetterHelp's 2023 FTC fine** ($7.8M, for sharing health data with ad platforms) — cited by name as a real precedent, no specific URL given in the doc
- **BetterHelp pricing/therapist-pay figures** ($260–400/mo subscriber pricing; ~$25–35/hr therapist pay) — described in the doc as "independently-corroborated ... across multiple sources," no single URL cited

## Behavioral / habit-loop research (HERMES — `product-concept/02-HERMES-offer-and-persona.md`)

Backs the "Notice → Name → Nudge" loop design and the explicit rejection of streaks/gamification.

- [Selzee — Eugene Schwartz's 5 Levels of Awareness](https://selzee.com/eugene-schwartz-5-levels-of-awareness)
- [Cambridge Core — Gamification and Nudging Techniques for Improving User Engagement in Mental Health and Well-Being Apps](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/EB2BEF667BFAE42422FE27C04FA2B0A3/S2732527X21004260a.pdf/gamification-and-nudging-techniques-for-improving-user-engagement-in-mental-health-and-wellbeing-apps.pdf)
- [JMIR Mental Health — Examining the Effectiveness of Gamification in Mental Health Apps for Depression](https://mental.jmir.org/2021/11/e32199)
- [PMC — Digital Behavior Change Intervention Designs for Habit Formation: Systematic Review](https://pmc.ncbi.nlm.nih.gov/articles/PMC11161714/)

## Technical / payments / crisis-content verification (Lego — `product-concept/04-Lego-technical-and-compliance.md`)

Real sources checked directly for the payment-descriptor and crisis-helpline items, not reused unverified.

- `razorpay.com/docs/payments/dashboard/account-settings/account-details` — checked directly for the payment statement-descriptor question (result: **inconclusive**, flagged as blocked pending Cult.fit's payments team)
- `telemanas.mohfw.gov.in` — Tele MANAS, India's Ministry of Health national mental-health helpline (14416, 24/7, 20+ languages) — the recommended anchor listing
- Vandrevala Foundation's own contact page — confirmed current number **+91 9999 666 555** (24/7, call + WhatsApp), different from the number commonly cited in older sources
- `dpdpa.com` — section-by-section DPDP Act 2023 text, checked directly for §12's consent-withdrawal-vs-erasure distinction
- **KIRAN helpline (1800-599-0019)** — checked and flagged as likely discontinued; cited evidence includes "at least one other project's own commit literally titled 'Replace the discontinued KIRAN helpline'" plus stale government press releases still listing it as active
- **iCall** — confirmed hours are 10 AM–8 PM Monday–Saturday, **not 24/7** — flagged as a real harm risk if shown without hours stated

## Repo / project links

- Repo: [github.com/loveluthra/kalakriti](https://github.com/loveluthra/kalakriti) — public, created 26 Sep, push still pending (see `brief/WORKFLOW.md`)
- Author: [@loveluthra](https://github.com/loveluthra) (per `README.md`)
- GitHub App install fix (if used instead of the manual bundle push): `github.com/apps/claude/installations/new`

## What's honestly missing

The mental-health-app mockup images that anchored the whole visual direction are described in `design/DIRECTION.md` but the actual image files aren't recoverable in this environment — they were uploaded to an earlier point in this conversation that predates this session's file access. If you still have them on your end, they belong in a `design/references/` folder in the repo so the visual lineage is actually traceable from the repo alone, not just asserted in prose. Everything else above is a real, checkable link.
