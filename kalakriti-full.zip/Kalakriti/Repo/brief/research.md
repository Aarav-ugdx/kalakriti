# Research — Cult.fit mental-health pivot

## 1. Cult.fit's real brand system

- **Design system name: Aurora.** Principles: Bold/Energetic/Immersive, Intent-Driven, Simply Efficient, Break the Mould. Built Atomic-Design style (sub-atomic particles → atoms → molecules → organisms → templates). Rebuilt in Flutter specifically because glassmorphism/blur at scale broke React Native performance — heavy blur/motion is core to the identity, not decoration.
- **Logomark:** circular, soft rounded edges, deliberately reads as inclusive/friendly/warm, not aggressive — even though the product surface (workout content) reads high-energy. Real license to lean warmer for the mental-health surface without breaking brand logic.
- **Palette:** Black, White, Yellow, Blue, Pink as primary brand colours; three gradients — Golden Hour, Daylight, **Midnight**; dedicated status colours (positive/neutral/awaiting/error). Commonly cited accent `#F06055` (coral/burnt-sienna). Aurora already runs **4 distinct colour themes across 8+ intent products** — precedent for a 5th, calmer theme rather than a one-off reskin.
- **Typography:** two explicit modes — task-focused (fast comprehension, e.g. booking/checkout) vs. emotive (provoke reaction, e.g. marketing/content). Use task-focused mode for booking steps, a toned-down emotive mode for content/resources — not the high-adrenaline version used for class marketing.
- **Photography:** real/bold/energetic, action shots, explicitly rejects "posed, low energy, flat, stockish." For therapy context: keep the *authenticity* principle (real people, not stock-therapy stethoscope-and-couch imagery) but drop the "mid-action" requirement — a still, natural portrait is authentic without being high-energy.
- **Layout:** 12-column mobile grid, consistent spacing scale — reuse as-is.
- Sources: [Aurora design language](https://blog.cult.fit/posts/aurora-design), [cult.fit brand assets](https://brandfetch.com/cult.fit), [design.cult.fit](https://design.cult.fit/popup/)

## 2. The core design tension (this is the actual brief)

Cult.fit's native mode is loud, dark, high-motion, red/coral-accented, action-photographed — tuned for "get pumped for a workout." Someone opening a mental-health section is often the opposite: possibly anxious, possibly booking their first-ever therapy session, wants to feel steadied, not activated. Round 2 criteria on color rationale and attention management are explicitly judging whether the team notices and resolves this. The lazy answer is generic pastel wellness-app cosplay that abandons brand fidelity. The credible answer uses Aurora's own stated flexibility (multiple themes, a Midnight gradient, task-focused type mode, a logomark whose intent is already "warm") to produce a fifth Aurora theme: same bones, dialled amplitude — dimmed glassmorphism, slower/softer motion curves, Midnight-based gradient instead of Daylight/Golden Hour, coral used only as a small accent (CTAs, not backgrounds), task-focused type throughout.

## 3. Competitor / pattern scan — mental-health & wellness apps

- **Wysa** (AI-first mental health chat + human therapist handoff): calm mascot/companion metaphor to soften a clinical topic, low-saturation palette, conversational (not form-heavy) onboarding, explicit crisis-escalation paths built into the flow rather than hidden in settings.
- **BetterHelp / Calm / general wellness-app UX literature:** (a) color psychology — cool blues/greens/soft neutrals read as calming, saturated warm reds/oranges read as urgent/alarming (direct implication for how far coral gets dialled back); (b) progressive disclosure in onboarding — one question at a time, not a form wall, because a vulnerable-state user disengages from long forms; (c) plain-language copy over clinical terminology; (d) generous whitespace and slower transition timing than a fitness app's UI.
- Sources: [UXmatters — color psychology for health/wellness apps](https://www.uxmatters.com/mt/archives/2024/07/leveraging-the-psychology-of-color-in-ux-design-for-health-and-wellness-apps.php), [Gapsy — mental health app design guide](https://gapsystudio.com/blog/mental-health-app-design/), [Gapsy — mental health website design](https://gapsystudio.com/blog/mental-health-website-design/), [Pixelbrainy — building an app like Wysa](https://www.pixelbrainy.com/blog/build-ai-mental-health-and-wellness-app-like-wysa)

## 4. Reused internal pattern language

A prior, unrelated team project (cycle-aware wellness tracking) already solved a structurally similar problem: tracking a personal, sometimes sensitive, cyclical state and adapting recommendations to it without turning the product clinical or alarming. The *pattern language* transfers, not the content:
- Symptom-tracking dashboard → **mood-tracking dashboard**: log a personal state quickly, see a trend, get one adaptive suggestion.
- Care handoff (when to point a user to a professional) → **therapist discovery/booking**: a moment where the product should get out of the way and connect a human, same non-alarmist, non-dismissive tone requirement.
- Non-preachy educational content → **content/resource screen**.
- Non-clinical tone research and freemium/claim boundaries (what the product will and won't claim to diagnose) directly informs Round 2's privacy/stigma/tone criterion.

## 5. Userbase call

Primary: first-time therapy seekers, urban 20-somethings — the segment most likely to be discovering both "community mental-health support" and "on-demand booking" as new concepts simultaneously. Secondary: existing Cult.fit members cross-shopping from fitness into mental health — for them the design should visually confirm "same app, new section," not a bolt-on. Accessibility for anxiety and cognitive load (explicitly named for this scenario) means: no dense text walls, no more than one decision per screen in the booking flow, a visible progress indicator, and an always-visible way out/back.
