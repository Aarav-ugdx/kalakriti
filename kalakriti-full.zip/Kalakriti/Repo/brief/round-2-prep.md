# Round 2 prep (only relevant if shortlisted)

Round 2 is a live presentation defending the Round 1 submission. This maps each judged criterion from the rulebook to what's actually in this repo, so the presentation is assembling existing answers, not writing new ones under time pressure on the 29th.

## 1. "Research into sensitivities specific to mental health UI (privacy, stigma, tone) vs. general fitness apps"

Point to: `brief/research.md` §2–3. The concrete decisions that came out of this research, visible in the screens:
- No star ratings/review counts on therapist profiles (privacy — a public review of a therapist exposes the client)
- The proposed booking-confirmation privacy line: "This booking stays out of shared activity, streaks, and your profile feed. Your therapist and authorised booking support can access the details needed for your session." This states the intended service access; the annotated screens do not implement access controls.
- No streaks/gamification anywhere in the Faye section, even though the illustrative Fitness home uses them (see the `00a`/`00b` comparison)
- Plain-language cancellation policy shown up front, not buried — first-time-booking anxiety is about commitment, address it before it's asked

## 2. "Colour scheme rationale for a calming, non-clinical, non-alarming feel"

Point to: `design/DIRECTION.md`. The rationale in one line: **we didn't invent a new palette — we pulled Aurora's own Yellow/Pink/Golden-Hour gradient logic forward and used it warm instead of dark, with coral demoted to CTA-only.** This is a stronger answer than "we made it blue and soft" because it's traceable to the existing brand system, not an outside wellness-app aesthetic bolted on. Show the `00a`/`00b` comparison to make the shift visible in one glance.

## 3. "How the design manages attention for a user who may be in a vulnerable state, avoiding overstimulation"

Concrete evidence in the screens: filter/concern selection is tap-chips, not a multi-field form (Screen 1); the booking flow has exactly one primary + one secondary action per screen, never more; the mood dashboard shows one adaptive suggestion, never a list of recommendations; the resource screen states each item's time cost before you tap in, so there's no open-ended commitment.

## 4. "Accessibility for users with anxiety, cognitive load sensitivity, visual impairments"

Point to: `brief/screen-flow.md`, its accessibility checklist, and **`brief/CONTRAST-AUDIT.md` specifically**. The submitted screens' audit measures contrast and records fixes. Its separate onboarding/keyboard appendix describes an archived prototype, not current submission screens. Cite the measured pairs and darker on-brand shade where needed; do not describe this as complete accessibility certification. Other planned requirements: generous tap targets, no auto-advancing content, text labels for icon controls, reduced-motion support when interaction is built, and plain-language copy.

## 5. "Userbase identification — age groups, first-time therapy seekers vs. existing Cult.fit members — and design decisions tied to that profile"

Primary: first-time therapy seekers, urban 20-somethings (renters/students/early-career) — encountering both "therapy" and "on-demand booking of it" as new concepts together. Secondary: existing Cult.fit members cross-shopping from fitness. Trace every decision above back to this explicitly when presenting — that traceability is what's actually being graded here, not the persona statement on its own.

For the **existing-member** segment, show the illustrative Fitness home → Faye tab comparison first: the familiar bottom navigation and booking-card conventions help members recognise where they are, while the warmer Aurora-derived surface signals a quieter task. Any future use of a Faye check-in for fitness recommendations requires a separate, initially off choice; the member can use Faye without that crossover. The booking privacy copy states what stays out of the shared fitness feed. These are design directions, not evidence of a live Cult.fit integration or deployed consent service.

## Standing rubric — where each lives

- **Problem Understanding** → `brief/rulebook-summary.md` + the design tension named in `brief/research.md` §2
- **Creative Innovation** → the Aurora-warm resolution (not a generic wellness reskin, not a dark reskin either) + the original mascot built from the existing logomark geometry
- **User-Centric Design** → `brief/screen-flow.md`, every "why" annotation
- **Visual Excellence** → the built screens themselves + the `00a`/`00b` comparison
- **Solution Viability** → cite reuse of familiar membership, booking, tracking, and content patterns as a design direction. Separate the annotated concept from a functioning booking, consent, mood-sync, or calendar service.
- **Final Presentation** → walk illustrative Fitness home → proposed Faye landing → the four required screens in their locked order. Use the annotated `design/screens.html` and README screenshots as the submission record.

For future brand positioning, **Faye by cult.fit** is an endorsed naming proposal inside the existing Faye tab; it is not in the current screens. Cult.fit's official materials already discuss mental wellbeing and therapy; describe the brief as a proposed integrated booking experience, not a claim that Cult.fit has no existing wellness offering. An official master logo asset is not in the repo; see `design/BRAND-AND-EXPERIENCE.md` and `design/UI-UX-IMPROVEMENT-PLAN.md` before applying this proposal.

## Open — needs Love/team input before Round 2, not before Round 1

- Real photography to replace the flat gradient avatar placeholders, if there's time
- Whether to record a short click-through video in addition to static screens (not required, but strengthens "Final Presentation")
