# Screen flow — content & IA spec (pre-visual)

Locked deliverable: therapist discovery → booking confirmation → mood-tracking dashboard → content/resource screen. This spec fixes *what's on each screen and why* before any pixels, so the design phase (once inspiration references land) is fast execution, not re-deciding structure.

## Entry point

New nav destination inside the existing Cult.fit tab bar (alongside Fitness, Cult Transform, etc.) — a new **Faye** tab. `research.md` §2 originally reasoned toward a dimmed, Midnight-based fifth Aurora theme for this entry; that idea was superseded once real design references arrived (see `design/DIRECTION.md`) by a warmer resolution that pulls forward Aurora's own Yellow/Pink/Golden-Hour gradient logic instead of dimming it. What ships (`design/screens.html`, screens `00b` onward) is a soft warm gradient-mesh + glassmorphism, not a dark theme — same underlying logic (a theme shift signals "different register" without leaving the app), warmer execution. This single transition *is* the answer to "how mental-health content is visually distinguished from physical-fitness content" — a theme shift on entry, not a different app. See the `00a`/`00b` comparison screens for this shown directly.

## Screen 1 — Therapist discovery

- Search/filter bar: concern (anxiety, stress, relationships, sleep...), language spoken, gender preference, availability (today / this week) — filters as chips, not a form.
- Therapist cards: photo (natural, still), name, credentials line, 1-line specialisation, next available slot, session price, a trust badge row (verified credential, years practising) reusing cult.fit's existing trainer-verification visual language.
- No star-rating/review-count front and center — public reviews of a therapist read as a client privacy problem. Use a quieter "recommended by X members like you" or omit — a deliberate trust-without-exposure decision, call it out explicitly in Round 2.
- Progressive disclosure: tapping a card expands in place (bottom sheet) rather than navigating away, keeping browsing context.

## Screen 2 — Booking confirmation

- Single-column summary: therapist, date/time, session type (video/in-person if applicable), price, cancellation policy stated plainly (not buried in T&Cs) — cancellation anxiety is a real first-time-user blocker.
- One primary CTA ("Confirm booking"), one secondary (back to edit) — no more than these two actions.
- Reuses the existing membership/class-booking confirmation pattern from cult.fit fitness (brand-fidelity requirement) — same component, different content.
- Post-confirmation state: a calm confirmation screen with what happens next (reminder will be sent, how to reschedule, a short privacy note on who can see this booking) — not a generic "success!" toast. For a first therapy booking the anxiety isn't "did it work," it's "who knows about this."

## Screen 3 — Mood-tracking dashboard

- Daily check-in: one-tap mood log (a small set of expressive icons, not a 1–10 numeric scale — numeric scoring reads clinical/diagnostic) plus an optional one-line note.
- Trend view: simple weekly line, not a dense chart — matches "avoid overstimulation" directly.
- One optional suggestion at a time: a guided breathing session or a relevant short article chosen from the user's stated concern or preference. Booking stays available through its own route; a few mood entries do not establish clinical need or trigger a paid-session prompt.
- Pattern reused from prior symptom-tracking work (see `research.md` §4): log fast → see trend → one suggestion, not ten metrics.

## Screen 4 — Content/resource screen

- Organised by concern (not by content type) — mirrors the discovery filters from Screen 1 for taxonomy consistency across the section.
- Mix of formats (short read, audio, guided exercise), each card states duration up front — respects limited attention/energy.
- The calmest screen in the flow — no gamification badges/streaks here, even though cult.fit uses streaks elsewhere for fitness — an explicit, callable-out exception to "reuse existing UI conventions," state it plainly in Round 2 rather than hiding it.

## Accessibility checklist (Round 2 criterion — build in now, don't retrofit)

- Minimum tap-target sizing and spacing generous enough for a shaky/distracted tap, not just compliant minimums.
- No auto-advancing carousels or timed content anywhere in this section.
- Every icon-only control has a text label available (not just on hover/long-press).
- Reduced motion is a requirement for any later interactive build. The current annotated screens are static; an archived prototype explored `prefers-reduced-motion`, but it is not part of the submission.
- Plain-language copy throughout; no clinical/diagnostic terminology in user-facing copy.
- **Color contrast — actually measured, not asserted:** see `brief/CONTRAST-AUDIT.md`. Two real WCAG AA failures were found in the first pass (CTA button text, therapist-card badge text — both from the bright brand coral being too mid-tone for text/solid-fill use) and fixed with a darker on-brand shade reserved for those two uses; everything else already passed.

## Userbase framing to state explicitly in Round 2

Primary: first-time therapy seekers, urban 20-somethings, likely renters/students/early-career — encountering both "therapy" and "on-demand booking of it" as new concepts together. Secondary: existing Cult.fit members cross-shopping, including first-time seekers who already know the Fitness shell and people who are already in therapy elsewhere and want to compare options. The familiar navigation and booking structure serve members; the warm Faye theme, clear privacy copy, and plain booking terms serve both groups. Someone with a working therapist should not be pressed to switch just to consolidate apps. The chip filters, one-tap mood icons, absence of public therapist reviews, and no Faye streaks address the primary segment's likely exposure and cognitive-load concerns. State these links in Round 2, since "design decisions tied to that profile" is a named judging line.
