# Rulebook summary — Kalakriti, Health & Well-Being, Scenario 2 (Cult.fit)

Condensed from the organisers' Guidelines & Rule Book (Veer Ladhani, Archit Sehgal). Read the full scenario text below before making any content changes — this is the actual grading spec.

## Rules that apply regardless of theme

- One theme, one scenario, chosen once — cannot change after Round 1 submission, for either round.
- Round 1: online, 26–27 Sep 2026, submit via Forms. **Closes 12:00 IST, 27 Sep 2026.**
- Round 2 (only if shortlisted): 29 Sep 2026, offline at MPSTME Mumbai; online arrangements for non-Mumbai teams.

## Scenario text (Health & Well-Being, Scenario 2 — Cult.fit)

> Imaginary pivot: an expansion into on-demand mental health & therapy booking. Cult.fit wants to extend beyond fitness into mental well-being — letting users book therapy sessions, track a simple wellness/mood score, and access guided content — integrated into the existing Cult.fit app and membership.

**Must stay intact (brand fidelity):**
- Cult.fit brand colors, logo, and energetic tone of voice
- Existing membership/class-booking interaction patterns
- Existing fitness-tracking UI conventions

**Open to redesign:**
- Therapist discovery & booking flow
- Mood/wellness tracking UI
- How mental health content is visually distinguished from physical fitness content

**Round 1 deliverable:** Screen flow covering: therapist discovery, booking confirmation, mood-tracking dashboard, and a content/resource screen. A clickable prototype or annotated screen flow.

**(If selected) Round 2 presentation must address:**
- Research into sensitivities specific to mental health UI (privacy, stigma, tone) vs. general fitness apps
- Color scheme rationale for a calming, non-clinical, non-alarming feel
- How the design manages attention for a user who may be in a vulnerable state, avoiding overstimulation
- Accessibility for users with anxiety, cognitive load sensitivity, or visual impairments
- Userbase identification — age groups, first-time therapy seekers vs. existing Cult.fit members — and how the design serves both

## Standing judging rubric (all rounds)

Problem Understanding · Creative Innovation · User-Centric Design · Visual Excellence · Solution Viability · Final Presentation.

## Submission format (confirmed separately by the team, not in the PDF itself)

Public link to Figma/Canva/any design software, **or** a public GitHub repo with screenshots in the README. Private links are skipped with no exception — verify reachability in an incognito window before submitting.
