# Contrast audit — real numbers, not an assertion

**Submission status:** the original six-screen measurements below apply to the annotated `design/screens.html` that remains in this repo. The later onboarding/keyboard appendix documents an experimental clickable prototype that was archived outside the submission. It is retained as historical research and must not be read as a claim that those interactive screens are currently included.

`brief/screen-flow.md`'s accessibility checklist claimed "reduced-motion respected... plain-language copy" etc. but never actually measured color contrast, despite Round 2 criterion #4 ("accessibility for users with anxiety, cognitive load sensitivity, visual impairments") being a named judging line. This computes real WCAG 2.x contrast ratios for every text/background pair in `design/screens.html` instead of asserting it.

## Method

Relative luminance and contrast ratio computed per the WCAG 2.x formula (`(L1+0.05)/(L2+0.05)`), with proper alpha compositing for every translucent layer (`.card`, `.chip`, `.navbar`, `.badge`, `.privacy`, `.dark .sub`, etc. all use `rgba()` — the *rendered* color depends on what's behind them, not the raw CSS value). Each text/background pair was checked against every stop color actually used in the relevant gradient (`.bg-warm`'s 6 stops, `.bg-dark`'s 4 stops, the two `.classcard` gradients) and scored against its **worst-case** stop — the conservative approach, since if a pair passes at its least favorable position on the gradient it passes everywhere else on it too.

Thresholds used: **4.5:1** for normal text, **3:1** for large text (≥24px regular / ≥18.66px bold) or non-text UI components, per WCAG 2.1 AA. Nothing here was scored against the more lenient "large text" bar unless the actual rendered font genuinely qualifies — no rounding a 15px bold button label up to "large" to make a number pass.

Script: a one-off Python check (luminance + compositing), not committed as a maintained tool — the two failures below are what mattered.

## Results

| Pair | Ratio (worst-case) | Verdict |
|---|---|---|
| Headline (`.h1`, ink) on warm bg | 12.5:1 | AAA |
| Subtext (`.sub`, ink-soft) on warm bg | 6.3:1 | AA |
| Chip text on chip bg | 17.0:1 | AAA |
| Active chip (white on ink) | 18.1:1 | AAA |
| **CTA button text (white) on coral bg** | **3.2:1** | **FAIL** |
| Ghost button text on warm bg | 12.5:1 | AAA |
| Card body text on card | 8.0:1 | AAA |
| **Therapist badge text on badge tint** | **2.5:1** | **FAIL** |
| Privacy/note text on note bg | 7.6:1 | AAA |
| Nav label (inactive) on navbar | 8.6:1 | AAA |
| Nav label (active, warm frame) — pre-fix | 3.0:1 | fails as normal text |
| Existing-Fitness screen (dark frame) — headline, subtext, class-card titles, streak text | 4.5:1 – 15.4:1 | all AA or better, no changes needed |

Two real failures, both from the same root cause: the bright brand coral (`#F06055`) is a mid-tone red-orange — vivid, but its luminance isn't low enough for white text on top of it, or dark enough as text on top of a light card, to clear 4.5:1. This is exactly the kind of thing that "designed on-brand" can miss if nobody actually measures it.

## Fixes shipped

Added one new token, `--coral-deep: #AD453D` (a deeper brick-red, same hue family, used only where brand coral was failing as **text or a solid CTA fill on a light background**):

- `.cta` background → `--coral-deep` (white CTA text now **5.7:1**, was 3.2:1)
- `.badge` → text color `--coral-deep`, background simplified from a coral-tinted pill to a plain light pill (was making it *worse* — a colored tint pushes the background toward the text's own hue, which lowers contrast, not raises it) → **5.4:1**, was 2.5:1
- `.navitem.on` (warm-frame nav label/icon, e.g. the active "Faye" tab) → `--coral-deep` → **5.3:1**, was 3.0:1

**Deliberately not changed:** the dark-frame's existing Fitness screen (`.dark .navitem.on`, the streak flame icon) keeps the original bright `--coral` — it already measures **5.7:1** on that near-black background, and darkening it there would only make it muddier for no gain. Brand fidelity (existing fitness screen "must stay intact") + a real number, not a blanket find-and-replace.

Bright `--coral` (`#F06055`) is kept as the primary brand accent everywhere else — decorative fills (mascot cheeks are unaffected; they're not text), avatar gradients, the streak flame — none of those are text-on-background pairs subject to WCAG contrast rules in the first place.

Screens re-rendered after the fix; see `design/screens/` for the current PNGs.

---

## Historical onboarding addendum (2026-09-26) — archived prototype

The original audit above covers the six locked screens in `design/screens.html`. It does **not** cover the onboarding sequence (`onb1`–`onb3`) ATELIER added to `design/prototype.html` — the real `role="switch"` consent toggle, the upgraded `role="radio"` mood-picker, the consent-error banner, and the step-dots. This section closes that gap, using the same method (WCAG 2.x relative-luminance contrast, proper alpha compositing against every gradient stop actually used, worst-case stop reported) plus, for keyboard operability, an actual Playwright session driving the real page — tabbing through elements, reading `document.activeElement`, firing real `Enter`/`Space`/`Tab` key events, and reading computed styles — not a read of the HTML and an assumption that `role="switch"` behaves correctly.

### Keyboard operability — tested, not assumed

Method: Playwright (Chromium) loaded `design/prototype.html` directly, focused a known anchor element inside each active screen (its back button), then drove `Tab`/`Enter`/`Space`/`ArrowRight` and read `document.activeElement` and `aria-checked` after each key.

| Check | Result |
|---|---|
| Consent toggle (`onb2`) reachable by a single `Tab` from the screen's back button | **Confirmed** |
| Toggle activates with `Enter` (false→true) and `Space` (true→false) | **Confirmed**, both directions |
| Toggle's visible focus ring present on keyboard focus | **Confirmed** — 3px solid, matches the global `:focus-visible` rule |
| Toggle's thumb actually moves and track actually recolors when `aria-checked` flips (not just a CSS rule that exists on paper) | **Confirmed** — read post-transition (`transform: translateX(20px)` on, `none` off; track background switches to `--coral-deep` on, per-fix color off, see below). A first pass that read computed style immediately after the attribute flip, before the 180ms CSS transition completed, misread this as broken — re-run with the transition allowed to finish showed it works correctly. Flagging the false alarm and how it was caught, not just the final number, since that's exactly the kind of assumption this check exists to catch. |
| First mood radio (`onb3`) reachable by a single `Tab` from the screen's back button | **Confirmed** |
| Mood radio activates with `Enter`; enables the "Preview check-in" CTA | **Confirmed** |
| Mood radio activates with `Space`; mutual exclusivity holds (previous selection's `aria-checked` reverts to false) | **Confirmed** |
| Arrow keys move focus and selection within the group; `Home` and `End` jump to the ends | **Confirmed in the 26 Sep follow-up browser check** |
| One `Tab` leaves the selected mood for "Preview check-in"; activating it reveals the mascot reaction and focuses "Continue to Faye" | **Confirmed in the 26 Sep follow-up browser check** |

**Historical follow-up fix:** the first pass found five separate `Tab` stops and no arrow-key behavior in the onboarding radiogroup. The archived prototype used roving `tabindex`: one `Tab` entered the group, arrow keys changed selection, and one `Tab` exited to the CTA. A Chromium check exercised `ArrowRight`, verified the selected radio's `aria-checked` and `tabindex`, then used `Tab` and `Enter` through the reaction state. Carry this pattern into any future interactive build and test it again there.

### Contrast — three new pairs checked, two real failures found and fixed, one confirmed passing

All three new colors ATELIER introduced were measured against the actual composited background they render on (card `frost` 62% white, further composited under some components, over every `bg-warm` gradient stop, worst case reported — same method as the original audit above).

| Pair | Ratio (worst-case) | Verdict |
|---|---|---|
| **Consent toggle, OFF state — thumb (white) vs. track (was `--frost-strong`, 82% white, on an already near-white card)** | **1.01:1** | **FAIL** — the switch was effectively invisible in its default (off) state, on the single most legally load-bearing screen in the flow (the DPDP consent gate defaults to exactly this state) |
| Consent toggle, OFF state — track vs. card behind it | **1.02:1** | **FAIL** — same root cause |
| Consent toggle, ON state — track (`--coral-deep`) vs. card / thumb vs. track | 4.95–5.68:1 | AA/AAA, no fix needed |
| **Consent-error banner text (`--coral-deep`) on its coral-tinted background** | **3.57:1** | **FAIL** against the 4.5:1 bar for a `role="alert"` banner |
| Step-dots, active (`--coral-deep`, opaque) vs. warm background | 3.92:1 (worst stop) | Passes 3:1 non-text bar, real but thin margin |
| **Step-dots, inactive (`rgba(23,21,26,0.16)`) vs. warm background** | **1.37–1.40:1** | **FAIL** — inactive dots were effectively invisible, defeating the point of a step indicator |

Two of the three failures share the original audit's exact root cause pattern: a translucent light fill on top of an already-light background renders far closer to white-on-white than the raw CSS alpha value suggests, and nobody had measured it. The error-banner failure has the same lesson as the original `.badge` fix — raising the coral tint's own opacity was tried and made contrast *worse*, not better (checked before assuming the fix direction), because bright coral's mid-tone luminance doesn't clear a text-contrast bar at any tint level; the working fix, like the original `.badge` fix, was to move to a plain light fill and carry the alert identity in the border instead of the wash.

### Fixes verified in the archived prototype

- `.toggle` (off state): track + border changed from `--frost-strong` / `--line` to `rgba(23,21,26,0.55)` → thumb-vs-track now **4.09:1**, track-vs-card now **3.87:1** (worst case), both clear WCAG 1.4.11's 3:1 non-text bar with real margin. On-state (`--coral-deep`) was already passing and is unchanged.
- `.consent-error`: background changed from a coral@12% tint to `--frost-strong`, border strengthened to `rgba(173,69,61,0.55)` to carry the alert identity → text-vs-background now **5.33:1** worst case, clears 4.5:1.
- `.stepdot` (inactive): background changed from `rgba(23,21,26,0.16)` to `rgba(23,21,26,0.5)` → **3.13–3.61:1** across stops, clears the 3:1 non-text bar. Active dot (`--coral-deep`) was already passing and is unchanged.

Re-checked with the same Playwright session after the fix: all keyboard-operability results above are from the **post-fix** file — the toggle's real, transition-complete visual states were re-verified to still animate correctly (`translateX(20px)` on / `none` off) after the CSS change, not just assumed to still work because the values changed.
